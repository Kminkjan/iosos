//
//  Note.swift
//  CompanyInfo
//
//  Created by Artemis Üncü on 15/03/16.
//  Copyright (c) 2016 Artemis Üncü. All rights reserved.
//

import Foundation


class Note{
    
    var name:String
    var description:String
    
    init(name:String, desc:String){
        self.name = name
        self.description=desc
    }
    
    var descProperty:String{
        get{
            return self.description
        }
        set(desc){
            self.description = desc
        }
    }
    var nameProperty:String{
        get{
            return self.name
        }
        set(newName){
            self.name = newName
        }
    }
    
}
