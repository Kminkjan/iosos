//
//  Company.swift
//  CompanyInfo
//
//  Created by Artemis Üncü on 15/03/16.
//  Copyright (c) 2016 Artemis Üncü. All rights reserved.
//

import Foundation


class Company{
    var id:String
    var name:String
    var telephone:String?
    var adres:String?
    var contactList:Array<Contact>
    
    
    init(name:String, telephone:String?, adres:String?){
        self.name = name
        self.id = NSUUID().UUIDString
        self.telephone = telephone
        self.adres = adres
        self.contactList=[Contact(name:"Derpina"), Contact(name:"Durpunu")]
    }
    
    var nameProperty : String{
        get{
            return self.name
        }
        set(newName){
            self.name=newName
        }
    }
    
    var idProperty : String {
        get {
            return self.id
        }
    }
    
    
    
}


