//
//  Model.swift
//  CompanyInfo
//
//  Created by Artemis Üncü on 15/03/16.
//  Copyright (c) 2016 Artemis Üncü. All rights reserved.
//

import Foundation

class Model{
    static let sharedInstance = Model()
    
    var companyList:Array<Company>
    private init(){
        let c1 = Company(name:"Kriscorp", telephone: " +31 527 893622", adres: "Awesomestreet")
        let c2 = Company(name:"Saxion", telephone: " +31 527 893622", adres: "Awesomestreet")
        let c3 = Company(name:"Artcorp", telephone: " +31 527 893622", adres: "Awesomestreet")
        
        companyList = [c1, c2, c3 ]
    }
    
    func getCompanies() -> Array<Company> {
        return self.companyList
    }
    
    func addCompany(company:Company){
        print("A fresh company apeared! " + company.name)
        companyList.append(company)
    }
    
    func editCompany(company:Company) {
        
    }
    
    func removeCompany(id:String){
        if let index = companyList.indexOf({ $0.id == id }){
            companyList.removeAtIndex(index)
        }
    }

}