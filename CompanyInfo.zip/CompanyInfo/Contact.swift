//
//  Contact.swift
//  CompanyInfo
//
//  Created by Artemis Üncü on 15/03/16.
//  Copyright (c) 2016 Artemis Üncü. All rights reserved.
//

import Foundation

class Contact{
    
    var noteList:Array<Note>
    
    var name:String
    var number:String
    
    init(name:String){
        self.name = name
        self.noteList = []
        number = ""
    }
    
    var phoneNumber : String{
        get{
            return self.phoneNumber
        }
        set(number){
            self.phoneNumber = number
        }
    }
    
    func addNote(note:Note){
        noteList.append(note)
    }
    func removeNote(note:Note){
        //for index in noteList
         //   if(noteList[index].name == note.name){
          //      noteList.removeAtIndex(index)
           // }
    }
    
}